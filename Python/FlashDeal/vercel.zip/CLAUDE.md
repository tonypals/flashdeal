# FlashDeal

## Översikt
Plattform för tidsbegränsade erbjudanden i fysiska butiker. Kunder prenumererar på kategorier och får notiser (mail/SMS) när butiker publicerar deals. Betalning sker vid bokning via Stripe Connect. Upphämtning verifieras med QR-kod.

## Stack
- Python Flask (backend), entry point: `api/index.py`
- Supabase (databas via REST) — `api/config.py` SupabaseREST-klass
- Stripe Connect (betalningar, 6% plattformsavgift)
- Gmail OAuth / SMTP (mail)
- 46elks (SMS)
- Vercel (hosting), `vercel.json` routar allt till `api/index.py`
- Vanilla JS, Jinja2 templates

## Struktur
```
api/
  index.py          ← Flask-app + blueprint-registrering
  config.py         ← SupabaseREST, mail, SMS, QR, Stripe, notiser
  routes/
    public.py       ← Startsida, erbjudanden, kategorier
    auth.py         ← Registrering + login (kund + butik)
    store.py        ← Butikspanel: erbjudanden, bokningar, QR-skanning
    booking.py      ← Bokning, Stripe checkout, bekräftelse
    admin.py        ← Plattformsadmin (PIN-skyddad)
  templates/
    base_dark.html  ← Kundvyer (mörkt tema)
    base_light.html ← Butiksadmin (ljust tema)
  static/
    css/dark.css, light.css
    js/scanner.js (jsQR), camera.js (bildtagning)
```

## Minnen
Se memory/MEMORY.md för projektkontext.

## Regler
- Kommunicera på svenska
- Hårt tak: ingen .py-fil > ~400 rader
- Priser lagras som NUMERIC (SEK med decimaler), multiplicera × 100 vid Stripe-anrop
- session['role'] = 'customer' | 'store' | 'admin'
- session['store_status'] måste vara 'approved' för butiksåtgärder
- Stripe webhook är sanningskälla för betalstatus — redirect-sidan visar bara UI
- Notis-throttle: max 1 notis per användare/kategori/kanal per 10 min (via notification_log)
- Alla Supabase-anrop sker server-side, aldrig i webbläsaren
- Statiska filer serveras av Flask från api/static/
