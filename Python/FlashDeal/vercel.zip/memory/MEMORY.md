# Memory Index

- [FlashDeal – projektöversikt](project_flashdeal.md) — stack, syfte, arkitektur, demo-läge, återstående setup
- [Tony – användarpreferenser](user_tony.md) — arbetssätt, bakgrund, vad som fungerar
