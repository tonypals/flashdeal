---
name: FlashDeal — projektöversikt
description: Stack, syfte, arkitektur och känsliga delar för FlashDeal-projektet
type: project
---

## Vad projektet är
Plattform för tidsbegränsade erbjudanden i fysiska butiker. Kunder prenumererar på kategorier, butiker publicerar deals, kunder bokar och betalar via Stripe, hämtar med QR-kod.

**Startad:** mars 2026
**Mapp:** `c:\Users\TOPAL02\OneDrive - Atea\Dokument\Scripts\Python\FlashDeal`

## Stack
- Flask + Vercel (entry point: `api/index.py`)
- Supabase via REST — custom wrapper `SupabaseREST` i `api/config.py`
- Stripe Connect (6% plattformsavgift, `STRIPE_PLATFORM_FEE_PCT`)
- Gmail OAuth (`GOOGLE_CREDENTIALS`) / SMTP fallback (`GMAIL_APP_PASSWORD`)
- 46elks (SMS, `ELKS_USERNAME` / `ELKS_PASSWORD`)
- Vanilla JS, Jinja2 templates

## Filstruktur
```
api/
  index.py        ← Flask-app + blueprint-registrering + Jinja-filter (price, timeago)
  config.py       ← SupabaseREST, mail, SMS, QR, bilduppladdning, notify_subscribers
  demo_data.py    ← hårdkodad testdata (aktiveras när SUPABASE_URL är tom)
  routes/
    public.py     ← startsida, erbjudande-detalj, butikslista, hur-det-fungerar
    auth.py       ← kund + butik: registrera, logga in, logga ut
    store.py      ← butikspanel /butik/*: dashboard, nytt erbjudande, bokningar, QR-scan, profil
    booking.py    ← checkout /betala/*: Stripe + testläge, webhook, bekräftelse, mina bokningar
    admin.py      ← plattformsadmin /admin/*: PIN-login, godkänn/avvisa butiker
  templates/
    base_dark.html      ← kundvyer (mörkt, orange accent #d4541a)
    base_light.html     ← butiksadmin (ljust, kräm-tema)
    index.html          ← startsida med erbjudandekort + kategoripills
    offer_detail.html   ← erbjudande-detaljsida
    stores_list.html    ← butikslista med filter på stad/kategori
    how_it_works.html   ← hur-det-fungerar
    for_stores.html     ← landningssida för butiker
    404.html
    auth/               ← register, login, store_register, store_login
    store/              ← dashboard, new_offer, bookings, scanner, scan_result, pending, profile
    booking/            ← checkout, confirmation, my_bookings, success_pending
    admin/              ← login, dashboard, stores, store_detail
  static/
    css/dark.css, light.css
    js/scanner.js       ← jsQR kamera-skanner
    js/camera.js        ← foto-preview vid erbjudandeskapande
docs/
  supabase-schema.sql   ← kör i Supabase SQL Editor (tabeller saknar fd_-prefix — BEHÖVER UPPDATERAS)
```

## Viktiga designbeslut
- **session['role']** = 'customer' | 'store' | 'admin'
- **session['store_status']** måste vara 'approved' för butiksåtgärder
- Stripe webhook (`/betala/webhook`) är sanningskälla — success-redirect visar bara UI
- Utan Stripe: `_test_checkout()` skapar bokning direkt med varningstext (visas i demo)
- Notis-throttle: max 1 notis/kund/kategori/kanal per 10 min (fd_notification_log)
- Priser lagras som NUMERIC i SEK, multipliceras × 100 för Stripe (öre)
- QR-token = 48-teckens hex, kopplad till boknings-ID, fungerar bara en gång
- Bilduppladdning: Supabase Storage bucket "offer-photos", max 5 MB
- Alla Supabase-tabeller har prefix `fd_` — implementerat i `SupabaseREST._ep()`

## Demo-läge (utan Supabase)
Aktiveras automatiskt när `SUPABASE_URL` är tom.
- `api/demo_data.py` innehåller: 15 kategorier, 7 butiker (6 godkända + 1 pending), 9 erbjudanden, 3 bokningar, 2 kunder
- Demo-butiker loggar in med lösenord: **`demo1234`**
- Demo-kunder loggar in med: `test@flashdeal.se` / `demo1234`
- Skrivoperationer (insert/update/delete) sparas i minnet och försvinner vid omstart
- Bilduppladdning fungerar inte i demo (photo_url = null, inga kraschar)
- Adminpanel: `/admin/logga-in`, PIN: **`9988`**

### Demo-butikslogins
| Butik | E-post | Lösenord |
|-------|--------|----------|
| Elgiganten Nordstan | elgiganten@demo.se | demo1234 |
| Sneakers & Co | sneakers@demo.se | demo1234 |
| Bageriet i Haga | bageriet@demo.se | demo1234 |
| Cykelkungen | cykelkungen@demo.se | demo1234 |
| Apotek Hjärtat | apotek@demo.se | demo1234 |
| Musikhuset | musikhuset@demo.se | demo1234 |

## Kör lokalt
```
start_local.bat   ← Windows, sätter env-variabler, skapar venv, kör python run.py
```
Utan Supabase-nycklar: demo-data används automatiskt.

## Återstår att sätta upp
- **Supabase**: kör `docs/supabase-schema.sql` i SQL Editor (uppdatera med fd_-prefix!)
- **Stripe**: skapa plattformskonto + aktivera Connect
- **Gmail**: antingen OAuth (token.json) eller app-lösenord
- **46elks**: konto + API-uppgifter
- **Vercel**: koppla GitHub-repo, sätt env-variabler i Dashboard

## Återstår att bygga
- GDPR-policy-sida (`/gdpr`) + consent-checkbox i registreringsformulären
- Butikens lösenordsbyte + kontostängning
- Adminpanel: statistik i demo-läge (nu tom utan Supabase)
- `docs/supabase-schema.sql` behöver uppdateras med `fd_`-prefix på alla tabeller
