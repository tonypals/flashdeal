---
name: Tony – global användarprofil
description: Tonys bakgrund, preferenser och arbetssätt — gäller alla projekt
type: user
---

## Vem är Tony

Tony Pal, bor i Göteborg. Bygger appar för hemmet och vardagslivet, primärt som ensam användare av sina egna system. Är inte professionell utvecklare — lär sig genom att göra. Använder Claude Code som primärt verktyg för att bygga och förvalta sina appar.

## Teknisk nivå

- Kan följa kod och förstå förklaringar på hög nivå
- Behöver inte djupa tekniska förklaringar om inte han frågar
- Kan hantera terminalen och köra kommandon
- Ny Claude Code-användare — lär sig fortfarande arbetsflödet
- Förväntar sig att Claude tar det tekniska ansvaret, han styr riktningen

## Preferenser och arbetssätt

- **Kommunicera alltid på svenska**
- Vill ha korta, direkta svar — inte långa förklaringar
- Vill se vad som faktiskt ändrats, inte en sammanfattning efteråt
- Föredrar att redigera befintliga filer framför att få nya
- Gillar att se progress — gärna dela upp i tydliga steg
- Ställer ofta frågor som "varför fungerar det inte?" — vill ha grundorsaken, inte bara fixen

## Vad Tony INTE vill ha

- Långa inledningar som upprepar vad han just sagt
- Onödiga kommentarer, docstrings eller felhantering som inte efterfrågats
- Hypotetiska förbättringar utanför det han frågat om
- Att Claude gissar sig fram — fråga hellre om oklart

## När Tony börjar om

Tony är medveten om att han ibland tänker fel och behöver börja om. Det är OK.
- Backa inte utan förklaring — berätta alltid varför något inte fungerade
- Spara alltid vad som lärts innan en revert
- Identifiera grundorsaken innan du föreslår en fix

## Stack och teknikval Tony känner till

- Flask (Python) — primärt webbramverk
- Supabase — databas och fillagring
- Vercel — deployment
- Jinja2 — templates
- Vanilla JS — inga frontend-ramverk
- Tailwind CSS (grundläggande)
- Git och GitHub

## Pågående projekt (uppdatera vid behov)

- **Hemappa** (`c:\scripts\hemapp`) — Flask+Supabase hemhanteringssystem, se projektets egna minnesfiler
