@echo off
REM ============================================================
REM  FlashDeal - Starta lokalt (Windows)
REM  Dubbelklicka pa den har filen for att kora appen.
REM
REM  Samma nycklar laggs in i Vercel Dashboard (Settings - Env)
REM  for produktion. Ingen .env-fil behovs.
REM ============================================================

echo.
echo  FlashDeal - startar lokal server...
echo.

REM ── Flask ────────────────────────────────────────────────────
set SESSION_SECRET=byt-till-nagot-slumpmassigt-langt-har
set FLASK_ENV=development
set FLASK_DEBUG=1
set BASE_URL=http://localhost:5000

REM ── Supabase ─────────────────────────────────────────────────
REM Hamta fran: supabase.com - Project Settings - API
REM Lamna tomma = demo-lage med hardkodad testdata
set SUPABASE_URL=https://frqoyrwhojvdmikizrvy.supabase.co
set SUPABASE_KEY=sb_secret_y3yOLmdayHoCayLewESCZg_GzpliVlI

REM ── Admin ────────────────────────────────────────────────────
set ADMIN_PIN=9988

REM ── Mail via Gmail ───────────────────────────────────────────
REM Alternativ A: Gmail OAuth (om du har kort credentials\get_credentials.py)
if exist credentials\token.json (
    for /f "usebackq delims=" %%i in (`python -c "import json; print(json.dumps(json.load(open('credentials/token.json'))))"`) do set GOOGLE_CREDENTIALS=%%i
    echo  [Mail] Gmail OAuth-token laddad fran credentials\token.json
) else (
    echo  [Mail] Ingen token.json - testlage, mail skrivs i terminalen.
)

REM Alternativ B: Gmail App Password (avkommentera och fyll i)
REM set GMAIL_USER=ditt.konto@gmail.com
REM set GMAIL_APP_PASSWORD=xxxx-xxxx-xxxx-xxxx

REM ── SMS via 46elks ───────────────────────────────────────────
REM Lamna tomma = testlage, SMS skrivs i terminalen
set ELKS_USERNAME=
set ELKS_PASSWORD=
set ELKS_FROM=FlashDeal

REM ── Stripe ───────────────────────────────────────────────────
REM Lamna tomma = testlage, bokning skapas utan betalning
set STRIPE_SECRET_KEY=
set STRIPE_PUBLISHABLE_KEY=
set STRIPE_WEBHOOK_SECRET=
set STRIPE_PLATFORM_FEE_PCT=6

REM ═════════════════════════════════════════════════════════════
REM  Ror inte nedanstående
REM ═════════════════════════════════════════════════════════════

REM Kontrollera Python
python --version >nul 2>&1
if errorlevel 1 (
    echo.
    echo  FEL: Python hittades inte!
    echo  Installera Python fran https://python.org
    echo.
    pause
    exit /b 1
)

REM Skapa virtual environment om det inte finns
if not exist venv (
    echo  Skapar virtual environment...
    python -m venv venv
)

REM Aktivera venv FORST, sedan pip
if exist venv\Scripts\activate.bat (
    echo  Aktiverar virtual environment...
    call venv\Scripts\activate.bat
) else (
    echo  VARNING: venv kunde inte aktiveras.
)

REM Installera paket bara om requirements.txt andrats sedan sist
set STAMP=venv\.pip_stamp
set REQ=requirements.txt
set NEEDS_INSTALL=0

if not exist %STAMP% (
    set NEEDS_INSTALL=1
) else (
    REM Jamfor timestamps med xcopy /L /D (kopierar ingenting, returnerar 0 om kalla ar nyare)
    xcopy /L /D /Y %REQ% %STAMP% >nul 2>&1
    if not errorlevel 1 set NEEDS_INSTALL=1
)

if "%NEEDS_INSTALL%"=="1" (
    echo  Installerar/uppdaterar paket...
    pip install -r requirements.txt --quiet
    if errorlevel 1 (
        echo  VARNING: Vissa paket kunde inte installeras.
    ) else (
        copy /Y %REQ% %STAMP% >nul
    )
) else (
    echo  Paket OK - ingen andring sedan sist.
)

REM Status-sammanfattning
echo.
echo  -------------------------------------------------
if defined SUPABASE_URL (
    echo   Supabase  OK - ansluter till databasen
) else (
    echo   Supabase  EJ konfigurerat
)
if defined GOOGLE_CREDENTIALS (
    echo   Mail      OK - Gmail OAuth
) else if defined GMAIL_APP_PASSWORD (
    echo   Mail      OK - Gmail SMTP
) else (
    echo   Mail      Testlage - skrivs i terminalen
)
if defined STRIPE_SECRET_KEY (
    echo   Stripe    OK - betalningar aktiva
) else (
    echo   Stripe    Testlage - ingen betalning
)
if defined ELKS_USERNAME (
    echo   SMS       OK - 46elks aktiv
) else (
    echo   SMS       Testlage - skrivs i terminalen
)
echo  -------------------------------------------------
echo.
echo  Appen kors pa:  http://localhost:5000
echo  Admin-panel:    http://localhost:5000/admin
echo  Butik-login:    http://localhost:5000/butik/logga-in
echo.
echo  Tryck Ctrl+C for att stoppa servern.
echo.

python run.py

echo.
echo  Servern stoppades.
echo.
pause
